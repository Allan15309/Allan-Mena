  // --- LOGO EN BASE64 ---
const CAY_SECURITY_LOGO_BASE64 =
    'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHBwgHBgoKCgkMCwsLDRUNDw0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDAEICgoKCgoKCjYQDQwNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDf/AABEIAGQAZAMBIgACEQARMRMBAf/AAGQAAACAAAEAAAIhBgAAAAAAAABkAAAAAAAAAAAAAAAAAAAAAAAAAABkAAAAkAAgCIMSAIAAgAAAAAAAAAgAAAAAEAAAGQACAAkAAIAAIAAAAAAAAAACAAACIAAAAEAAACAAIAACAAAAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ//Z';


// --- Contenido del Manual de Usuario ---
const USER_MANUAL_TEXT = `
    <h2>Manual de Usuario: Generador de Contraseñas CAY Security</h2>
    <p>Este manual te guiará a través de las funciones principales de la aplicación para que puedas generar, gestionar y verificar contraseñas de forma segura y eficiente.</p>

    <h3>1. Generador de Contraseñas Estándar</h3>
    <p>La sección principal te permite crear contraseñas fuertes y personalizadas.</p>
    <ul>
        <li><strong>Longitud de Contraseña:</strong> Usa el campo de número o el control deslizante para elegir la longitud, de 4 a 32 caracteres. Las contraseñas más largas son más seguras.</li>
        <li><strong>Opciones de Caracteres:</strong> Marca las casillas para incluir <strong>Mayúsculas</strong>, <strong>Números</strong> y <strong>Caracteres Especiales</strong>. La opción <strong>"Excluir Caracteres Ambiguos"</strong> es útil para evitar caracteres que pueden confundirse, como <code>l</code>, <code>I</code>, <code>O</code>, <code>0</code> y <code>1</code>, ideal para contraseñas que tengas que escribir a mano.</li>
        <li><strong>Cantidad a Generar:</strong> Elige cuántas contraseñas quieres crear. Si seleccionas más de una, todas se guardarán automáticamente en tu historial.</li>
        <li><strong>Botón "Generar Contraseña":</strong> Haz clic aquí para crear una nueva contraseña según las opciones seleccionadas.</li>
        <li><strong>Indicador de Fortaleza:</strong> Después de generar una contraseña, verás un indicador visual (Débil, Media, Fuerte) y sugerencias para mejorar su seguridad.</li>
        <li><strong>Gestión de la Contraseña Generada:</strong> Usa el botón "Copiar" para copiarla al portapapeles y el botón del ojo (<code>&#128065;</code>) para ver u ocultar la contraseña.</li>
    </ul>

    <h3>2. Generador de Frases de Contraseña (Passphrase)</h3>
    <p>Esta sección te ayuda a crear frases de contraseña (passphrases), que son secuencias de palabras aleatorias. Son muy seguras y, a menudo, más fáciles de recordar que las contraseñas complejas.</p>
    <ul>
        <li><strong>Número de Palabras:</strong> Selecciona de 3 a 8 palabras para tu frase. Más palabras significan mayor seguridad.</li>
        <li><strong>Separador:</strong> Elige el carácter que separará cada palabra (guión, espacio, etc.).</li>
        <li><strong>Capitalizar y Números:</strong> Puedes elegir si capitalizar la primera letra de cada palabra y si añadir un número aleatorio a la frase.</li>
        <li><strong>Botón "Generar Frase":</strong> Crea tu passphrase con las opciones elegidas.</li>
        <li><strong>Nota:</strong> Estas frases de contraseña también se guardan en tu historial.</li>
    </ul>

    <h3>3. Verificar Contraseña Comprometida</h3>
    <p>Esta función te ayuda a saber si una contraseña ya ha sido expuesta en una filtración de datos pública, utilizando el servicio "Have I Been Pwned".</p>
    <ul>
        <li><strong>Campo de Texto:</strong> Pega una contraseña aquí para verificarla.</li>
        <li><strong>Importante:</strong> Para proteger tu privacidad, solo se envían de forma segura los primeros 5 caracteres del hash (una huella digital) de la contraseña, no la contraseña completa.</li>
        <li><strong>Botón "Verificar Ahora":</strong> Haz clic para iniciar la verificación. Si la contraseña se encuentra en una filtración, el sistema te lo notificará.</li>
    </ul>

    <h3>4. Historial de Contraseñas</h3>
    <p>En esta sección, puedes gestionar todas las contraseñas y frases de contraseña que has generado y guardado.</p>
    <ul>
        <li><strong>Lista de Historial:</strong> Aquí verás una lista de todos tus elementos generados, con su longitud, tipo (Contraseña o Passphrase) y fecha de creación.</li>
        <li><strong>Botones de Gestión:</strong>
            <ul>
                <li><strong>Exportar a PDF:</strong> Genera un documento PDF con todo tu historial.</li>
                <li><strong>Importar Historial:</strong> Sube un archivo JSON para restaurar o combinar un historial previamente guardado.</li>
                <li><strong>Limpiar Historial:</strong> Borra de forma permanente todas las contraseñas guardadas.</li>
            </ul>
        </li>
    </ul>
`;

// --- Lista de palabras para Passphrases (¡IMPORTANTE: REEMPLAZA ESTO!) ---
const wordList = [
    "sol", "luna", "estrella", "arbol", "rio", "montaña", "flor", "mar", "nube", "viento",
    "casa", "perro", "gato", "pajaro", "pez", "libro", "lapiz", "mesa", "silla", "coche",
    "azul", "verde", "rojo", "amarillo", "blanco", "negro", "grande", "pequeño", "rapido", "lento",
    "futuro", "tecnologia", "seguridad", "privacidad", "digital", "algoritmo", "cripto", "clave", "cifrado",
    "navegar", "explorar", "descubrir", "conectar", "innovar", "proteger", "acceso", "identidad", "datos",
    "sistema", "red", "servidor", "internet", "enlace", "protocolo", "aplicacion", "software", "hardware", "nucleo"
];

let logoImage = null;

document.addEventListener('DOMContentLoaded', async function() {
    // --- Referencias a los elementos del DOM ---
    const passwordInput = document.getElementById('password');
    const togglePasswordVisibilityBtn = document.getElementById('toggle-password-visibility');
    const generateBtn = document.getElementById('generate-btn');
    const copyBtn = document.getElementById('copy-btn');
    const lengthInput = document.getElementById('length');
    const lengthRangeInput = document.getElementById('length-range');
    const includeSpecialCharsCheckbox = document.getElementById('include-special');
    const includeUppercaseCheckbox = document.getElementById('include-uppercase');
    const includeNumbersCheckbox = document.getElementById('include-numbers');
    const excludeAmbiguousCheckbox = document.getElementById('exclude-ambiguous');
    const numPasswordsInput = document.getElementById('num-passwords');
    const numPasswordsRangeInput = document.getElementById('num-passwords-range');
    const strengthIndicator = document.getElementById('strength-indicator');
    const requirementsFeedback = document.getElementById('requirements-feedback');
    const savedPasswordsList = document.getElementById('saved-passwords-list');
    const clearSavedBtn = document.getElementById('clear-saved-btn');
    const exportHistoryBtn = document.getElementById('export-history-btn');
    const importHistoryBtn = document.getElementById('import-history-btn');
    const importHistoryFile = document.getElementById('import-history-file');
    const themeToggleBtn = document.getElementById('theme-toggle');
    const notificationMessage = document.getElementById('notification-message');
    const checkPasswordInput = document.getElementById('check-password-input');
    const checkPwnedBtn = document.getElementById('check-pwned-btn');
    const manualBtn = document.getElementById('manual-btn');
    const manualModal = document.getElementById('manual-modal');
    const closeManualBtn = document.querySelector('.close-btn');
    const manualContent = document.getElementById('manual-content');

    // --- Nuevos elementos para Passphrase ---
    const passphraseOutput = document.getElementById('passphrase-output');
    const copyPassphraseBtn = document.getElementById('copy-passphrase-btn');
    const togglePassphraseVisibility = document.getElementById('toggle-passphrase-visibility');
    const generatePassphraseBtn = document.getElementById('generate-passphrase-btn');
    const wordCountInput = document.getElementById('word-count');
    const wordCountRange = document.getElementById('word-count-range');
    const separatorSelect = document.getElementById('separator');
    const capitalizeFirstLetterCheckbox = document.getElementById('capitalize-first-letter');
    const addRandomNumberCheckbox = document.getElementById('add-random-number');

    // --- Conjuntos de caracteres ---
    const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
    const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numberChars = '0123456789';
    const specialChars = '!@#$%^&*()_+[]{}|;:,.<>?';
    const ambiguousChars = 'lIO01';

    // --- Cargar el logo al inicio de la página ---
    try {
        logoImage = new Image();
        logoImage.src = CAY_SECURITY_LOGO_BASE64;
        await new Promise((resolve, reject) => {
            logoImage.onload = resolve;
            logoImage.onerror = () => {
                console.error('Error al cargar la imagen del logo.');
                reject();
            };
        });
        console.log('Logo de CAY Security cargado correctamente.');
    } catch (e) {
        console.error('Fallo al cargar el logo:', e);
        logoImage = null;
    }

    // --- Configuración inicial al cargar la página ---
    lengthInput.value = lengthRangeInput.value = 12;
    numPasswordsInput.value = numPasswordsRangeInput.value = 1;
    wordCountInput.value = wordCountRange.value = 4;
    applySavedTheme();
    generatePasswordsBasedOnCount();
    generatePassphrase();
    loadAndDisplaySavedPasswords();
    manualContent.innerHTML = USER_MANUAL_TEXT;
    updateThemeIcon(); // Llamada inicial para mostrar el icono correcto

    // --- Event Listeners ---
    generateBtn.addEventListener('click', generatePasswordsBasedOnCount);
    copyBtn.addEventListener('click', () => copyToClipboard(passwordInput.value, copyBtn));
    clearSavedBtn.addEventListener('click', clearAllSavedPasswords);
    togglePasswordVisibilityBtn.addEventListener('click', () => toggleVisibility(passwordInput, togglePasswordVisibilityBtn));
    exportHistoryBtn.addEventListener('click', exportHistoryToPdf);
    importHistoryBtn.addEventListener('click', () => importHistoryFile.click());
    importHistoryFile.addEventListener('change', importHistory);
    themeToggleBtn.addEventListener('click', () => {
        toggleTheme();
        updateThemeIcon();
    });
    manualBtn.addEventListener('click', () => manualModal.style.display = 'block');
    closeManualBtn.addEventListener('click', () => manualModal.style.display = 'none');
    window.addEventListener('click', (event) => {
        if (event.target == manualModal) {
            manualModal.style.display = 'none';
        }
    });

    lengthInput.addEventListener('input', () => {
        lengthRangeInput.value = lengthInput.value;
        generatePasswordsBasedOnCount();
    });
    lengthRangeInput.addEventListener('input', () => {
        lengthInput.value = lengthRangeInput.value;
        generatePasswordsBasedOnCount();
    });
    numPasswordsInput.addEventListener('input', () => {
        numPasswordsRangeInput.value = numPasswordsInput.value;
        generatePasswordsBasedOnCount();
    });
    numPasswordsRangeInput.addEventListener('input', () => {
        numPasswordsInput.value = numPasswordsRangeInput.value;
        generatePasswordsBasedOnCount();
    });

    includeSpecialCharsCheckbox.addEventListener('change', generatePasswordsBasedOnCount);
    includeUppercaseCheckbox.addEventListener('change', generatePasswordsBasedOnCount);
    includeNumbersCheckbox.addEventListener('change', generatePasswordsBasedOnCount);
    excludeAmbiguousCheckbox.addEventListener('change', generatePasswordsBasedOnCount);

    checkPwnedBtn.addEventListener('click', async () => {
        const passwordToCheck = checkPasswordInput.value;
        if (passwordToCheck) {
            await checkPwnedPassword(passwordToCheck);
        } else {
            showNotification('Por favor, ingresa una contraseña para verificar.', 'info');
        }
    });

    // --- Event Listeners para Passphrase ---
    generatePassphraseBtn.addEventListener('click', generatePassphrase);
    copyPassphraseBtn.addEventListener('click', () => copyToClipboard(passphraseOutput.value, copyPassphraseBtn));
    togglePassphraseVisibility.addEventListener('click', () => toggleVisibility(passphraseOutput, togglePassphraseVisibility));
    wordCountInput.addEventListener('input', () => {
        wordCountRange.value = wordCountInput.value;
        generatePassphrase();
    });
    wordCountRange.addEventListener('input', () => {
        wordCountInput.value = wordCountRange.value;
        generatePassphrase();
    });
    separatorSelect.addEventListener('change', generatePassphrase);
    capitalizeFirstLetterCheckbox.addEventListener('change', generatePassphrase);
    addRandomNumberCheckbox.addEventListener('change', generatePassphrase);


    // --- Lógica del Generador de Contraseñas ---
    async function generatePasswordsBasedOnCount() {
        const numPasswords = parseInt(numPasswordsInput.value);
        if (isNaN(numPasswords) || numPasswords < 1 || numPasswords > 10) {
            showNotification('Por favor, ingresa una cantidad de contraseñas válida (entre 1 y 10).', 'error');
            return;
        }

        if (numPasswords === 1) {
            const newPassword = generateSinglePassword();
            if (newPassword) {
                passwordInput.value = newPassword;
                checkPasswordStrength(newPassword);
                checkRequirementsAndProvideFeedback(newPassword);
                savePassword(newPassword, 'password');
                await checkPwnedPassword(newPassword);
            }
        } else {
            passwordInput.value = 'Generando múltiples...';
            strengthIndicator.className = '';
            strengthIndicator.textContent = '';
            requirementsFeedback.textContent = '';
            for (let i = 0; i < numPasswords; i++) {
                const newPassword = generateSinglePassword();
                if (newPassword) {
                    savePassword(newPassword, 'password');
                }
            }
            loadAndDisplaySavedPasswords();
            showNotification(`Se han generado y guardado ${numPasswords} contraseñas en el historial.`, 'success');
        }
    }

    function generateSinglePassword() {
        const passwordLength = parseInt(lengthInput.value);
        const includeSpecial = includeSpecialCharsCheckbox.checked;
        const includeUppercase = includeUppercaseCheckbox.checked;
        const includeNumbers = includeNumbersCheckbox.checked;
        const excludeAmbiguous = excludeAmbiguousCheckbox.checked;

        if (isNaN(passwordLength) || passwordLength < 4 || passwordLength > 32) {
            showNotification('La longitud de la contraseña debe ser entre 4 y 32 caracteres.', 'error');
            return '';
        }

        let allChars = lowercaseChars;
        let guaranteedChars = [];

        if (!includeUppercase && !includeNumbers && !includeSpecial) {
            guaranteedChars.push(getRandomChar(lowercaseChars));
        } else {
            if (includeUppercase) {
                allChars += uppercaseChars;
                guaranteedChars.push(getRandomChar(uppercaseChars));
            }
            if (includeNumbers) {
                allChars += numberChars;
                guaranteedChars.push(getRandomChar(numberChars));
            }
            if (includeSpecial) {
                allChars += specialChars;
                guaranteedChars.push(getRandomChar(specialChars));
            }
            if (lowercaseChars.length > 0 && allChars.includes(lowercaseChars[0]) && !guaranteedChars.some(char => lowercaseChars.includes(char))) {
                guaranteedChars.push(getRandomChar(lowercaseChars));
            }
        }

        let currentAllChars = allChars;
        if (excludeAmbiguous) {
            currentAllChars = filterAmbiguous(allChars);
            guaranteedChars = guaranteedChars.filter(char => !ambiguousChars.includes(char));
            while (guaranteedChars.length < Math.min(passwordLength, 1) && currentAllChars.length > 0) {
                guaranteedChars.push(getRandomChar(currentAllChars));
            }
        }

        if (currentAllChars.length === 0 || passwordLength < guaranteedChars.length) {
            showNotification('No se pueden generar caracteres suficientes con las opciones seleccionadas (especialmente al excluir ambiguos y una longitud baja).', 'error');
            return '';
        }

        guaranteedChars = guaranteedChars.slice(0, passwordLength);

        let password = '';
        for (let i = 0; i < passwordLength - guaranteedChars.length; i++) {
            password += getRandomChar(currentAllChars);
        }

        password = (password + guaranteedChars.join(''))
            .split('')
            .sort(() => Math.random() - 0.5)
            .join('');

        password = password.substring(0, passwordLength);

        return password;
    }

    // --- Lógica del Generador de Frases de Contraseña ---
    function generatePassphrase() {
        const wordCount = parseInt(wordCountInput.value);
        const separator = separatorSelect.value === 'Espacio' ? ' ' : separatorSelect.value;
        const capitalize = capitalizeFirstLetterCheckbox.checked;
        const addNumber = addRandomNumberCheckbox.checked;

        if (isNaN(wordCount) || wordCount < 3 || wordCount > 8) {
            showNotification('El número de palabras debe ser entre 3 y 8.', 'error');
            return '';
        }

        let passphrase = [];
        let shuffledWordList = [...wordList].sort(() => Math.random() - 0.5);
        for (let i = 0; i < wordCount; i++) {
            let word = shuffledWordList[i];
            if (capitalize) {
                word = word.charAt(0).toUpperCase() + word.slice(1);
            }
            passphrase.push(word);
        }

        let finalPassphrase = passphrase.join(separator);

        if (addNumber) {
            finalPassphrase += separator + Math.floor(Math.random() * 100);
        }

        passphraseOutput.value = finalPassphrase;
        savePassword(finalPassphrase, 'passphrase');
    }

    function filterAmbiguous(charSet) {
        return charSet.split('').filter(char => !ambiguousChars.includes(char)).join('');
    }

    function getRandomChar(charSet) {
        if (charSet.length === 0) return '';
        const randomIndex = Math.floor(Math.random() * charSet.length);
        return charSet.charAt(randomIndex);
    }

    function toggleVisibility(inputElement, buttonElement) {
        if (inputElement.type === 'password') {
            inputElement.type = 'text';
            buttonElement.textContent = '🙈';
        } else {
            inputElement.type = 'password';
            buttonElement.textContent = '👀';
        }
    }

    function copyToClipboard(text, button) {
        if (!navigator.clipboard) {
            const textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.position = "fixed";
            textArea.style.left = "-9999px";
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            try {
                document.execCommand('copy');
                showNotification('Copiado al portapapeles: ' + text.substring(0, 20) + '...', 'success');
            } catch (err) {
                console.error('Error al copiar al portapapeles:', err);
                showNotification('No se pudo copiar. Por favor, cópialo manualmente.', 'error');
            }
            document.body.removeChild(textArea);
            return;
        }
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Copiado al portapapeles.', 'success');
            // Feedback visual del botón
            button.classList.add('copied-feedback');
            setTimeout(() => {
                button.classList.remove('copied-feedback');
            }, 1000);
        }).catch(err => {
            console.error('Error al copiar al portapapeles:', err);
            showNotification('No se pudo copiar. Por favor, cópialo manualmente.', 'error');
        });
    }

    function checkPasswordStrength(password) {
        let strength = 0;
        const indicators = strengthIndicator;
        indicators.className = '';

        if (password.length >= 8) strength++;
        if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
        if (password.match(/\d/)) strength++;
        if (password.match(/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/)) strength++;
        if (password.length >= 12 && strength >= 3) strength++;

        if (strength <= 1) {
            indicators.classList.add('weak');
            indicators.textContent = 'Débil';
        } else if (strength === 2) {
            indicators.classList.add('medium');
            indicators.textContent = 'Media';
        } else {
            indicators.classList.add('strong');
            indicators.textContent = 'Fuerte';
        }
    }

    function checkRequirementsAndProvideFeedback(password) {
        let feedbackMessage = '';
        const length = parseInt(lengthInput.value);

        if (length < 8) {
            feedbackMessage += 'Considera una longitud de al menos 8 caracteres para mayor seguridad. ';
        }
        if (!includeUppercaseCheckbox.checked) {
            feedbackMessage += 'Añadir mayúsculas aumentará la fortaleza. ';
        }
        if (!includeNumbersCheckbox.checked) {

            feedbackMessage += 'Añadir números aumentará la fortaleza. ';
        }
        if (!includeSpecialCharsCheckbox.checked) {
            feedbackMessage += 'Añadir caracteres especiales aumentará la fortaleza. ';
        }

        requirementsFeedback.textContent = feedbackMessage.trim();
    }

    async function checkPwnedPassword(password) {
        showNotification('Verificando si tu contraseña ha sido comprometida...', 'info');

        try {
            const sha1Hash = await sha1(password);
            const prefix = sha1Hash.substring(0, 5);
            const suffix = sha1Hash.substring(5).toUpperCase();

            const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.text();
            const matches = data.split('\n').filter(line => line.startsWith(suffix));

            if (matches.length > 0) {
                const count = matches[0].split(':')[1];
                showNotification(`¡ADVERTENCIA! Esta contraseña ha sido encontrada ${count} veces en filtraciones de datos públicas. Cámbiala inmediatamente.`, 'error', 15000);
                return true;
            } else {
                showNotification('¡Excelente! Esta contraseña no ha sido encontrada en filtraciones de datos públicas.', 'success');
                return false;
            }
        } catch (error) {
            console.error('Error al verificar la contraseña en HIBP:', error);
            showNotification('Error al verificar la contraseña. Inténtalo de nuevo más tarde.', 'error');
            return null;
        }
    }

    async function sha1(str) {
        const textEncoder = new TextEncoder();
        const data = textEncoder.encode(str);
        const hashBuffer = await crypto.subtle.digest('SHA-1', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const sha1Hash = hashArray.map(byte => byte.toString(16).padStart(2, '0')).join('');
        return sha1Hash.toUpperCase();
    }

    function savePassword(item, type = 'password', options = {}) {
        let savedItems = JSON.parse(localStorage.getItem('passwords')) || [];
        const itemEntry = {
            item: item,
            type: type,
            length: item.length,
            timestamp: new Date().toISOString(),
            ...options
        };

        if (type === 'password') {
            itemEntry.includeSpecial = includeSpecialCharsCheckbox.checked;
            itemEntry.includeUppercase = includeUppercaseCheckbox.checked;
            itemEntry.includeNumbers = includeNumbersCheckbox.checked;
            itemEntry.excludeAmbiguous = excludeAmbiguousCheckbox.checked;
        } else if (type === 'passphrase') {
            itemEntry.wordCount = parseInt(wordCountInput.value);
            itemEntry.separator = separatorSelect.value;
            itemEntry.capitalizeFirstLetter = capitalizeFirstLetterCheckbox.checked;
            itemEntry.addRandomNumber = addRandomNumberCheckbox.checked;
        }

        const isDuplicate = savedItems.some(entry =>
            entry.item === itemEntry.item && entry.type === itemEntry.type
        );
        if (!isDuplicate) {
            savedItems.push(itemEntry);
            localStorage.setItem('passwords', JSON.stringify(savedItems));
            console.log('Elemento guardado:', itemEntry);
            loadAndDisplaySavedPasswords();
        } else {
            console.log('Elemento similar ya existe, no guardado:', itemEntry.item);
        }
    }

    function loadAndDisplaySavedPasswords() {
        const savedItems = JSON.parse(localStorage.getItem('passwords')) || [];
        savedPasswordsList.innerHTML = '';
        if (savedItems.length === 0) {
            savedPasswordsList.innerHTML = '<li class="empty-message">No hay elementos en el historial.</li>';
            return;
        }
        savedItems.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        savedItems.forEach((entry, index) => {
            const listItem = document.createElement('li');
            listItem.classList.add(entry.type);
            const date = new Date(entry.timestamp);
            const formattedDate = date.toLocaleString('es-ES', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            let optionsString = '';

            if (entry.type === 'password') {
                let options = [];
                if (entry.includeUppercase) options.push('Mayúsculas');
                if (entry.includeNumbers) options.push('Números');
                if (entry.includeSpecial) options.push('Especiales');
                if (entry.excludeAmbiguous) options.push('Sin Ambigüedades');
                optionsString = options.length > 0 ? options.join(', ') : 'Solo minúsculas';
            } else if (entry.type === 'passphrase') {
                let options = [];
                if (entry.capitalizeFirstLetter) options.push('Capitalizado');
                if (entry.addRandomNumber) options.push('Con Número');
                optionsString = `Palabras: ${entry.wordCount}, Separador: ${entry.separator} | ` + (options.length > 0 ? options.join(', ') : 'Sin opciones');
            }

            listItem.innerHTML = `
                <span class="password-text">${entry.item}</span>
                <span class="metadata">
                    Tipo: ${entry.type === 'password' ? 'Contraseña' : 'Frase'} |
                    Longitud: ${entry.length} |
                    Opciones: ${optionsString} |
                    Generada: ${formattedDate}
                </span>
                <button class="delete-btn" data-index="${index}">Eliminar</button>
            `;
            savedPasswordsList.appendChild(listItem);
        });

        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', deletePassword);
        });
    }

    function deletePassword(event) {
        const indexToDelete = parseInt(event.target.dataset.index);
        let savedItems = JSON.parse(localStorage.getItem('passwords')) || [];
        savedItems.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        savedItems.splice(indexToDelete, 1);
        localStorage.setItem('passwords', JSON.stringify(savedItems));
        console.log('Elemento eliminado del historial.');
        loadAndDisplaySavedPasswords();
        showNotification('Elemento eliminado del historial.', 'success');
    }

    function clearAllSavedPasswords() {
        if (confirm('¿Estás seguro de que quieres eliminar TODO el historial de contraseñas guardadas? Esta acción es irreversible.')) {
            localStorage.removeItem('passwords');
            console.log('Todos los elementos guardados han sido eliminados.');
            loadAndDisplaySavedPasswords();
            showNotification('Todos los elementos guardados han sido eliminados.', 'success');
        }
    }

    async function exportHistoryToPdf() {
        if (typeof window.jspdf === 'undefined' || typeof window.jspdf.jsPDF === 'undefined') {
            showNotification('Error: La librería jsPDF no está cargada. Asegúrate de que tu conexión a internet funciona y que la etiqueta <script> está en el HTML.', 'error', 10000);
            console.error('jsPDF no está cargado. Verifique el enlace en su archivo index.html.');
            return;
        }

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF('p', 'mm', 'a4');
        const imgWidth = 25;
        const imgHeight = 25;
        const imgX = doc.internal.pageSize.width - imgWidth - 10;
        const imgY = 10;

        const savedItems = JSON.parse(localStorage.getItem('passwords')) || [];
        savedItems.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        let y = 20;
        const margin = 15;
        const lineHeight = 7;
        const maxPageHeight = doc.internal.pageSize.height - margin;

        if (logoImage) {
            doc.addImage(logoImage, 'JPEG', imgX, imgY, imgWidth, imgHeight);
        } else {
            console.warn('El logo no se ha podido cargar, el PDF se generará sin él.');
        }

        y = Math.max(y, imgY + imgHeight + 10);

        doc.setFontSize(18);
        doc.setTextColor(0, 0, 0);
        doc.text('Historial de Contraseñas y Frases de Contraseña', doc.internal.pageSize.width / 2, y, {
            align: 'center'
        });
        y += 10;
        doc.setFontSize(10);
        doc.setTextColor(100, 100, 100);
        doc.text(`Fecha de Exportación: ${new Date().toLocaleString('es-ES')}`, doc.internal.pageSize.width - margin, y, {
            align: 'right'
        });
        y += 10;

        if (savedItems.length === 0) {
            doc.setFontSize(12);
            doc.setTextColor(50, 50, 50);
            doc.text('No hay elementos en el historial para exportar.', margin, y);
        } else {
            savedItems.forEach((entry) => {
                if (y + lineHeight * 3 > maxPageHeight) {
                    doc.addPage();
                    y = margin;

                    if (logoImage) {
                        doc.addImage(logoImage, 'JPEG', imgX, imgY, imgWidth, imgHeight);
                    }
                    y = Math.max(y, imgY + imgHeight + 10);
                    doc.setFontSize(18);
                    doc.setTextColor(0, 0, 0);
                    doc.text('Historial de Contraseñas y Frases de Contraseña (continuación)', doc.internal.pageSize.width / 2, y, {
                        align: 'center'
                    });
                    y += 10;
                }

                doc.setFontSize(12);
                doc.setFont(undefined, 'bold');
                const typeText = entry.type === 'password' ? 'Contraseña' : 'Frase de Contraseña';
                doc.text(`${typeText}: ${entry.item}`, margin, y);
                y += lineHeight;

                doc.setFontSize(9);
                doc.setFont(undefined, 'normal');
                const formattedDate = new Date(entry.timestamp).toLocaleString('es-ES');
                let optionsString = '';

                if (entry.type === 'password') {
                    let options = [];
                    if (entry.includeUppercase) options.push('Mayúsculas');
                    if (entry.includeNumbers) options.push('Números');
                    if (entry.includeSpecial) options.push('Especiales');
                    if (entry.excludeAmbiguous) options.push('Sin Ambigüedades');
                    optionsString = options.length > 0 ? options.join(', ') : 'Solo minúsculas';
                } else if (entry.type === 'passphrase') {
                    let options = [];
                    if (entry.capitalizeFirstLetter) options.push('Capitalizado');
                    if (entry.addRandomNumber) options.push('Con Número');
                    optionsString = `Palabras: ${entry.wordCount}, Separador: ${entry.separator} | ` + (options.length > 0 ? options.join(', ') : 'Sin opciones');
                }

                doc.text(`Longitud: ${entry.length} | Opciones: ${optionsString} | Generada: ${formattedDate}`, margin, y);
                y += lineHeight + 5;
            });
        }

        doc.save('historial_contraseñas_CAY.pdf');
        showNotification('Historial exportado a PDF correctamente.', 'success');
    }

    function importHistory(event) {
        const file = event.target.files[0];
        if (!file) {
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                if (Array.isArray(importedData)) {
                    let currentData = JSON.parse(localStorage.getItem('passwords')) || [];
                    const uniqueNewItems = importedData.filter(newItem =>
                        !currentData.some(existingItem =>
                            existingItem.item === newItem.item && existingItem.type === newItem.type
                        )
                    );
                    currentData = [...currentData, ...uniqueNewItems];
                    localStorage.setItem('passwords', JSON.stringify(currentData));
                    loadAndDisplaySavedPasswords();
                    showNotification(`Se han importado ${uniqueNewItems.length} nuevos elementos al historial.`, 'success');
                } else {
                    showNotification('El formato del archivo JSON no es válido. Debe ser un array.', 'error');
                }
            } catch (error) {
                console.error('Error al importar el historial:', error);
                showNotification('Error al leer el archivo. Asegúrate de que sea un archivo JSON válido.', 'error');
            }
        };
        reader.readAsText(file);
    }

    // --- CAMBIO: Lógica para alternar la clase 'light-theme' ---
    function toggleTheme() {
        document.body.classList.toggle('light-theme');
        const isLightTheme = document.body.classList.contains('light-theme');
        localStorage.setItem('theme', isLightTheme ? 'light' : 'dark');
    }

    // --- CAMBIO: Lógica para aplicar el tema guardado al inicio ---
    function applySavedTheme() {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'light') {
            document.body.classList.add('light-theme');
        } else {
            // Si no hay preferencia o es 'dark', se usa el tema por defecto del CSS.
            document.body.classList.remove('light-theme');
        }
    }

    function updateThemeIcon() {
        const isLightTheme = document.body.classList.contains('light-theme');
        themeToggleBtn.innerHTML = isLightTheme ? '☀️' : '🌙';
    }

    function showNotification(message, type = 'info', duration = 5000) {
        notificationMessage.textContent = message;
        notificationMessage.className = `notification ${type}`;
        notificationMessage.style.display = 'block';

        setTimeout(() => {
            notificationMessage.style.display = 'none';
        }, duration);
    }
});